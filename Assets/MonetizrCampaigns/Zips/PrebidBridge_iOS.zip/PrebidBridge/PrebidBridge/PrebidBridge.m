// PrebidBridge.m
// iOS native bridge for Monetizr Prebid
// Parity with Android + automatic in-app enrichment for endpoint JSON (InMobi-friendly)

#import <Foundation/Foundation.h>
#import <dispatch/dispatch.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>
#import <AdSupport/AdSupport.h>
#import <AppTrackingTransparency/AppTrackingTransparency.h>
#import <PrebidMobile/PrebidMobile.h>

#ifdef __cplusplus
extern "C" {
#endif
void prebid_init_default_host(void);
void prebid_init_with_host(const char* hostUrlUtf8);
typedef void (*PBUnityStaticCallback)(const char* resultUtf8, void* userData);
void prebid_fetch_demand(const char* prebidDataUtf8,
                         const char* hostUrlUtf8,
                         PBUnityStaticCallback cb,
                         void* userData);
const char* prebid_get_iab_tcf_consent(void);
const char* prebid_get_iab_us_privacy(void);
void prebid_free_string(const char* p);
#ifdef __cplusplus
}
#endif

static NSString * const kDefaultOpenRTBURL = @"https://rtb.monetizr.com/openrtb2/auction";

// ---------- Helpers ----------
static inline const char* dup_utf8(NSString* s) {
    if (!s) return NULL;
    NSData* d = [s dataUsingEncoding:NSUTF8StringEncoding];
    if (!d) return NULL;
    char* buf = (char*)malloc(d.length + 1);
    if (!buf) return NULL;
    memcpy(buf, d.bytes, d.length);
    buf[d.length] = 0;
    return buf;
}
static inline NSString* PBStr(const char* s) { return s ? [NSString stringWithUTF8String:s] : @""; }
static inline BOOL isJsonLike(const char* s) {
    if (!s) return NO;
    while (*s==' '||*s=='\n'||*s=='\t'||*s=='\r') ++s;
    return (*s=='{' || *s=='[');
}

// If there are no double quotes but there ARE single quotes, swap them (Android parity).
static NSString* EnsureValidJsonQuotes(NSString *s) {
    if (s.length == 0) return s;
    NSString *t = [s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    unichar c = [t characterAtIndex:0];
    if (c != '{' && c != '[') return s;
    if ([t rangeOfString:@"\""].location == NSNotFound &&
        [t rangeOfString:@"'"].location != NSNotFound) {
        return [t stringByReplacingOccurrencesOfString:@"'" withString:@"\""];
    }
    return s;
}

// Quote any unquoted object keys (e.g., protocols: -> "protocols":)
static NSString* QuoteUnquotedKeys(NSString *s) {
    NSError *err = nil;
    NSRegularExpression *rx =
      [NSRegularExpression regularExpressionWithPattern:
       @"(?<=\\{|,)\\s*([A-Za-z_][A-Za-z0-9_\\-]*)\\s*:"
       options:NSRegularExpressionDotMatchesLineSeparators error:&err];
    if (err) return s;
    NSMutableString *m = [s mutableCopy];
    NSArray<NSTextCheckingResult*> *matches =
      [rx matchesInString:s options:0 range:NSMakeRange(0, s.length)];
    for (NSInteger i = (NSInteger)matches.count - 1; i >= 0; --i) {
        NSRange keyRange = [matches[i] rangeAtIndex:1];
        NSString *key = [s substringWithRange:keyRange];
        [m replaceCharactersInRange:keyRange withString:[NSString stringWithFormat:@"\"%@\"", key]];
    }
    return m;
}

// ---------- In-app enrichment for endpoint JSON ----------
// Returns a JSON string; if strict parse fails, returns original.
static NSString* EnrichOpenRtbForInApp(NSString *jsonIn) {
    NSData *d = [jsonIn dataUsingEncoding:NSUTF8StringEncoding];
    if (!d) return jsonIn;
    NSError *err = nil;
    id obj = [NSJSONSerialization JSONObjectWithData:d options:NSJSONReadingMutableContainers error:&err];
    if (err || ![obj isKindOfClass:[NSDictionary class]]) return jsonIn;

    NSMutableDictionary *root = [(NSDictionary *)obj mutableCopy];

    // --- app.bundle (preferred for in-app) ---
    NSMutableDictionary *app = [root[@"app"] isKindOfClass:[NSDictionary class]] ? [root[@"app"] mutableCopy] : [NSMutableDictionary dictionary];
    if (!app[@"bundle"]) {
        NSString *bundleId = [[NSBundle mainBundle] bundleIdentifier] ?: @"";
        if (bundleId.length) app[@"bundle"] = bundleId;
    }
    if (app.count) root[@"app"] = app;

    // --- device fields ---
    NSMutableDictionary *device = [root[@"device"] isKindOfClass:[NSDictionary class]] ? [root[@"device"] mutableCopy] : [NSMutableDictionary dictionary];

    // --- ifa / lmt (compute tracking status + IDFA) ---
    BOOL lmt = 1;                  // 1 = limit/ad tracking ON (no IDFA), 0 = allowed
    NSString *ifa = nil;

    if (@available(iOS 14, *)) {
        ATTrackingManagerAuthorizationStatus st = [ATTrackingManager trackingAuthorizationStatus];
        if (st == ATTrackingManagerAuthorizationStatusAuthorized) {
            NSUUID *idfa = [[ASIdentifierManager sharedManager] advertisingIdentifier];
            if (idfa) ifa = [idfa UUIDString];
            lmt = 0;
        } else {
            lmt = 1;
        }
    } else {
        if ([[ASIdentifierManager sharedManager] isAdvertisingTrackingEnabled]) {
            NSUUID *idfa = [[ASIdentifierManager sharedManager] advertisingIdentifier];
            if (idfa) ifa = [idfa UUIDString];
            lmt = 0;
        } else {
            lmt = 1;
        }
    }

    // Write IFA if missing
    if (!device[@"ifa"] && ifa.length) {
        device[@"ifa"] = ifa;
    }

    // --- device.lmt: force integer 0/1, never boolean ---
    id existingLmt = device[@"lmt"];
    if (existingLmt && [existingLmt isKindOfClass:[NSNumber class]]) {
        // Coerce any prior boolean/number to 0/1 integer
        device[@"lmt"] = @(((NSNumber *)existingLmt).integerValue ? 1 : 0);
    } else {
        // Our computed BOOL -> explicit 0/1
        device[@"lmt"] = @((lmt ? 1 : 0));
    }


    // os / osv / model
    UIDevice *dev = [UIDevice currentDevice];
    if (!device[@"os"])  device[@"os"]  = @"iOS";
    if (!device[@"osv"]) device[@"osv"] = dev.systemVersion ?: @"";
    if (!device[@"model"]) device[@"model"] = dev.model ?: @"";

    // Don't inject fake ip/ua; let PBS infer from headers if you didn't set them.

    if (device.count) root[@"device"] = device;

    // --- privacy: GDPR/TCF + CCPA ---
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *tcf = [ud stringForKey:@"IABTCF_TCString"];
    id rawGdpr = [ud objectForKey:@"IABTCF_gdprApplies"]; // may be BOOL or NSNumber
    NSNumber *gdprFlag = nil;
    if ([rawGdpr respondsToSelector:@selector(integerValue)]) {
        gdprFlag = @([rawGdpr integerValue]); // force 0/1 integer, not true/false
    }
    NSString *usPrivacy = [ud stringForKey:@"IABUSPrivacy_String"];

    // user.ext.consent
    if (tcf.length) {
        NSMutableDictionary *user = [root[@"user"] isKindOfClass:[NSDictionary class]] ? [root[@"user"] mutableCopy] : [NSMutableDictionary dictionary];
        NSMutableDictionary *uext = [user[@"ext"] isKindOfClass:[NSDictionary class]] ? [user[@"ext"] mutableCopy] : [NSMutableDictionary dictionary];
        if (!uext[@"consent"]) uext[@"consent"] = tcf;
        if (uext.count) user[@"ext"] = uext;
        if (user.count) root[@"user"] = user;
    }

    // regs.ext.gdpr / us_privacy
    if (gdprFlag || usPrivacy.length) {
        NSMutableDictionary *regs = [root[@"regs"] isKindOfClass:[NSDictionary class]] ? [root[@"regs"] mutableCopy] : [NSMutableDictionary dictionary];
        NSMutableDictionary *rext = [regs[@"ext"] isKindOfClass:[NSDictionary class]] ? [regs[@"ext"] mutableCopy] : [NSMutableDictionary dictionary];
        if (gdprFlag && !rext[@"gdpr"]) rext[@"gdpr"] = gdprFlag;            // now 0/1
        if (usPrivacy.length && !rext[@"us_privacy"]) rext[@"us_privacy"] = usPrivacy;
        if (rext.count) regs[@"ext"] = rext;
        if (regs.count) root[@"regs"] = regs;
    }

    NSData *out = [NSJSONSerialization dataWithJSONObject:root options:0 error:nil];
    return out ? [[NSString alloc] initWithData:out encoding:NSUTF8StringEncoding] : jsonIn;
}

// Simple HTTP POST; returns body as UTF-8 string (even on non-200)
static void HttpPostJson(NSString *urlStr, NSString *json, void (^done)(NSString *body)) {
    if (urlStr.length == 0) urlStr = kDefaultOpenRTBURL;
    NSURL *url = [NSURL URLWithString:urlStr];
    if (!url) { if (done) done(@"" ); return; }

    NSData *body = [json dataUsingEncoding:NSUTF8StringEncoding] ?: [NSData data];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    req.HTTPMethod = @"POST";
    req.HTTPBody   = body;
    [req setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [req setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];

    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *resp, NSError *err) {
        NSString *respBody = data.length ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : @"";
        if (err) NSLog(@"[PrebidBridge][iOS] HTTP error: %@", err.localizedDescription);
        if ([resp isKindOfClass:[NSHTTPURLResponse class]]) {
            NSInteger code = [(NSHTTPURLResponse*)resp statusCode];
            if (code < 200 || code >= 300) {
                NSLog(@"[PrebidBridge][iOS] HTTP %ld body=%@", (long)code, respBody ?: @"");
            }
        }
        
        NSLog(@"[PrebidBridge][iOS] PBS FULL RESPONSE (%lu bytes): %@", (unsigned long)respBody.length, respBody);
        
        if (done) done(respBody ?: @"");
        [session finishTasksAndInvalidate];
    }] resume];
}

// ---------- Privacy C API ----------
const char* prebid_get_iab_tcf_consent(void) {
    NSString *v = [[NSUserDefaults standardUserDefaults] stringForKey:@"IABTCF_TCString"] ?: @"";
    return dup_utf8(v);
}
const char* prebid_get_iab_us_privacy(void) {
    NSString *v = [[NSUserDefaults standardUserDefaults] stringForKey:@"IABUSPrivacy_String"] ?: @"";
    return dup_utf8(v);
}
void prebid_free_string(const char* p) { if (p) free((void*)p); }

// ---------- Init ----------
void prebid_init_default_host(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [Prebid shared].prebidServerHost = PrebidHostAppnexus;
        [Prebid initializeSDK:nil];
        NSLog(@"[PrebidBridge] Initialized with default host (AppNexus)");
    });
}
void prebid_init_with_host(const char* hostUrlUtf8) {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *url = PBStr(hostUrlUtf8);
        if (url.length > 0) {
            NSError *err = nil;
            [Prebid shared].prebidServerHost = PrebidHostCustom;
            [[Prebid shared] setCustomPrebidServerWithUrl:url error:&err];
            if (err) NSLog(@"[PrebidBridge] setCustomPrebidServer error: %@", err);
        } else {
            [Prebid shared].prebidServerHost = PrebidHostAppnexus;
        }
        [Prebid initializeSDK:nil];
        NSLog(@"[PrebidBridge] Initialized with custom/default host: %@", url);
    });
}

// ---------- Demand (Android parity) ----------
void prebid_fetch_demand(const char* prebidDataUtf8,
                         const char* hostUrlUtf8,
                         PBUnityStaticCallback cb,
                         void* userData)
{
    if (!cb) return;

    NSString *dataIn = PBStr(prebidDataUtf8);
    NSString *hostIn = PBStr(hostUrlUtf8);

    if (dataIn.length == 0) {
        dispatch_async(dispatch_get_main_queue(), ^{ cb(dup_utf8(@""), userData); });
        return;
    }

    // Mode A: Raw OpenRTB JSON → POST to PBS and return body as-is
    if (isJsonLike(prebidDataUtf8)) {
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            @try {
                NSString *json = EnsureValidJsonQuotes(dataIn);
                json = QuoteUnquotedKeys(json);
                json = EnrichOpenRtbForInApp(json);  // <-- add app/device/privacy if missing

                NSString *finalHost = hostIn.length ? hostIn : kDefaultOpenRTBURL;
                HttpPostJson(finalHost, json, ^(NSString *body){
                    dispatch_async(dispatch_get_main_queue(), ^{
                        cb(dup_utf8(body ?: @""), userData);
                    });
                });
            } @catch (NSException *ex) {
                NSLog(@"[PrebidBridge][iOS] JSON flow error: %@", ex.reason);
                dispatch_async(dispatch_get_main_queue(), ^{ cb(dup_utf8(@""), userData); });
            }
        });
        return;
    }

    // Mode B: Stored Config ID via SDK → return { resultCode, targeting }
    dispatch_async(dispatch_get_main_queue(), ^{
        @try {
            NSString *configId = dataIn;
            VideoAdUnit *adUnit = [[VideoAdUnit alloc] initWithConfigId:configId
                                                                   size:CGSizeMake(640, 480)];
            VideoParameters *params = [[VideoParameters alloc] initWithMimes:@[@"video/mp4"]];
            adUnit.parameters = params;

            [adUnit fetchDemandWithCompletion:^(ResultCode result,
                                               NSDictionary<NSString*, NSString*> * _Nullable targeting)
            {
                NSString *rc = @"UNKNOWN";
                switch (result) {
                    case ResultCodePrebidDemandFetchSuccess: rc = @"PrebidDemandFetched"; break;
                    case ResultCodePrebidDemandNoBids:       rc = @"PrebidDemandNoBids";  break;
                    case ResultCodePrebidDemandTimedOut:     rc = @"PrebidDemandTimedOut";break;
                    default:                                  rc = @"UNKNOWN";             break;
                }

                NSError *err = nil;
                NSData *tData = [NSJSONSerialization dataWithJSONObject:(targeting ?: @{})
                                                                options:0 error:&err];
                NSString *tJson = tData ? [[NSString alloc] initWithData:tData encoding:NSUTF8StringEncoding] : @"{}";
                NSString *out = [NSString stringWithFormat:@"{\"resultCode\":\"%s\",\"targeting\":%s}",
                                 rc.UTF8String, tJson.UTF8String];

                dispatch_async(dispatch_get_main_queue(), ^{
                    cb(dup_utf8(out), userData);
                });
            }];
        } @catch (NSException *ex) {
            NSLog(@"[PrebidBridge][iOS] SDK flow error: %@", ex.reason);
            cb(dup_utf8(@""), userData);
        }
    });
}
